
import { Button } from '@/components/ui/button';
import { Home, Eye, History, Settings, TrendingUp } from 'lucide-react';

export const Navigation = ({ activeScreen, onScreenChange }) => {
  const navItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'live', label: 'Track Live', icon: Eye },
    { id: 'history', label: 'History', icon: History },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <>
      {/* Mobile Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-slate-900/90 backdrop-blur-sm border-t border-slate-700/50 p-4 lg:hidden">
        <div className="flex justify-around">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <Button
                key={item.id}
                variant="ghost"
                size="sm"
                onClick={() => onScreenChange(item.id)}
                className={`flex flex-col items-center space-y-1 text-xs ${
                  activeScreen === item.id
                    ? 'text-blue-400 bg-blue-500/20'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{item.label}</span>
              </Button>
            );
          })}
        </div>
      </nav>

      {/* Desktop Navigation */}
      <div className="hidden lg:block fixed left-4 top-1/2 transform -translate-y-1/2">
        <div className="bg-slate-900/80 backdrop-blur-sm rounded-2xl p-3 border border-slate-700/50">
          <div className="flex flex-col space-y-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <Button
                  key={item.id}
                  variant="ghost"
                  size="sm"
                  onClick={() => onScreenChange(item.id)}
                  className={`w-12 h-12 p-0 ${
                    activeScreen === item.id
                      ? 'text-blue-400 bg-blue-500/20'
                      : 'text-slate-400 hover:text-white'
                  }`}
                  title={item.label}
                >
                  <Icon className="w-5 h-5" />
                </Button>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
};
