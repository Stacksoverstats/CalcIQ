
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, XCircle, Clock, TrendingUp } from 'lucide-react';

export const LiveTracker = () => {
  const activeParlays = [
    {
      id: 1,
      title: "Evening 3-Leg Parlay",
      stake: 50,
      potentialPayout: 285,
      legs: [
        { team: "Yankees", betType: "ML", status: "won", score: "Yankees 7 - Red Sox 3", time: "Final" },
        { team: "Dodgers", betType: "Over 8.5", status: "won", score: "Dodgers 6 - Giants 4", time: "Final" },
        { team: "Astros", betType: "ML", status: "live", score: "Astros 3 - Rangers 2", time: "7th Inning" }
      ],
      status: "alive"
    },
    {
      id: 2,
      title: "College Baseball Special",
      stake: 25,
      potentialPayout: 156,
      legs: [
        { team: "LSU", betType: "ML", status: "won", score: "LSU 8 - Florida 2", time: "Final" },
        { team: "Texas", betType: "-1.5", status: "lost", score: "Oklahoma 5 - Texas 4", time: "Final" },
        { team: "Alabama", betType: "ML", status: "pending", score: "vs Auburn", time: "7:00 PM" }
      ],
      status: "lost"
    }
  ];

  const getStatusIcon = (status) => {
    switch (status) {
      case 'won': return <CheckCircle className="w-5 h-5 text-green-400" />;
      case 'lost': return <XCircle className="w-5 h-5 text-red-400" />;
      case 'live': return <Clock className="w-5 h-5 text-blue-400 animate-pulse" />;
      case 'pending': return <Clock className="w-5 h-5 text-slate-400" />;
      default: return null;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'won': return 'border-green-500/30 bg-green-500/10';
      case 'lost': return 'border-red-500/30 bg-red-500/10';
      case 'live': return 'border-blue-500/30 bg-blue-500/10';
      case 'pending': return 'border-slate-500/30 bg-slate-500/10';
      default: return 'border-slate-500/30 bg-slate-500/10';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <TrendingUp className="w-6 h-6 text-blue-400" />
        <h2 className="text-2xl font-bold text-white">Live Parlay Tracker</h2>
      </div>

      {activeParlays.map((parlay) => (
        <Card key={parlay.id} className="bg-slate-900/50 backdrop-blur-sm border-slate-700/50 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold text-white">{parlay.title}</h3>
            <Badge className={`${parlay.status === 'alive' ? 'bg-green-500/20 text-green-400 border-green-500/30' : 'bg-red-500/20 text-red-400 border-red-500/30'}`}>
              {parlay.status === 'alive' ? 'Parlay Still Alive!' : 'Parlay Lost'}
            </Badge>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className="bg-slate-800/30 rounded-lg p-3">
              <p className="text-slate-400 text-sm">Stake</p>
              <p className="text-white font-bold">${parlay.stake}</p>
            </div>
            <div className="bg-slate-800/30 rounded-lg p-3">
              <p className="text-slate-400 text-sm">Potential Payout</p>
              <p className="text-green-400 font-bold">${parlay.potentialPayout}</p>
            </div>
          </div>

          {/* Parlay Legs */}
          <div className="space-y-3">
            {parlay.legs.map((leg, index) => (
              <div key={index} className={`p-4 rounded-lg border ${getStatusColor(leg.status)}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    {getStatusIcon(leg.status)}
                    <div>
                      <p className="text-white font-medium">{leg.team} {leg.betType}</p>
                      <p className="text-slate-400 text-sm">{leg.score}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-slate-400 text-sm">{leg.time}</p>
                    <Badge variant="outline" className={`mt-1 text-xs ${
                      leg.status === 'won' ? 'border-green-500 text-green-400' :
                      leg.status === 'lost' ? 'border-red-500 text-red-400' :
                      leg.status === 'live' ? 'border-blue-500 text-blue-400' :
                      'border-slate-500 text-slate-400'
                    }`}>
                      {leg.status.toUpperCase()}
                    </Badge>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Progress Bar */}
          <div className="mt-4">
            <div className="flex justify-between text-sm text-slate-400 mb-2">
              <span>Progress</span>
              <span>{parlay.legs.filter(leg => leg.status === 'won').length} / {parlay.legs.length} legs complete</span>
            </div>
            <div className="w-full bg-slate-700 rounded-full h-2">
              <div
                className={`h-2 rounded-full transition-all duration-300 ${
                  parlay.status === 'alive' ? 'bg-gradient-to-r from-green-500 to-blue-500' : 'bg-red-500'
                }`}
                style={{ width: `${(parlay.legs.filter(leg => leg.status === 'won').length / parlay.legs.length) * 100}%` }}
              />
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
};
