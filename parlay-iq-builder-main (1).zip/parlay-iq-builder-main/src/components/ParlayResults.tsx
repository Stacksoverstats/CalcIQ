import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calculator, ExternalLink, TrendingUp, Shield, AlertTriangle, Flame, DollarSign } from 'lucide-react';

export const ParlayResults = ({ parlayData }) => {
  const stake = Number(parlayData?.stake) || 0;
  
  const sampleParlays = [
    {
      id: 1,
      title: "Parlay Calculation #1",
      legs: [
        { team: "LSU", betType: "Moneyline", odds: "-150", confidence: 92, risk: "safe" },
        { team: "Yankees", betType: "Run Line -1.5", odds: "+120", confidence: 88, risk: "safe" },
        { team: "Dodgers", betType: "Over 8.5", odds: "-110", confidence: 91, risk: "safe" }
      ],
      combinedOdds: "+285",
      payout: (stake * 3.85).toFixed(2),
      winRate: 92,
      bestPlatforms: ["DraftKings", "FanDuel", "BetMGM"]
    },
    {
      id: 2,
      title: "Parlay Calculation #2",
      legs: [
        { team: "Texas", betType: "Moneyline", odds: "+110", confidence: 85, risk: "moderate" },
        { team: "Astros", betType: "Over 9.5", odds: "-105", confidence: 89, risk: "safe" },
        { team: "Alabama", betType: "Run Line -2.5", odds: "+165", confidence: 78, risk: "risky" }
      ],
      combinedOdds: "+425",
      payout: (stake * 5.25).toFixed(2),
      winRate: 76,
      bestPlatforms: ["Caesars", "BetRivers", "PointsBet"]
    }
  ];

  const getRiskIcon = (risk) => {
    switch (risk) {
      case 'safe': return <Shield className="w-4 h-4 text-green-400" />;
      case 'moderate': return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
      case 'risky': return <Flame className="w-4 h-4 text-red-400" />;
      default: return null;
    }
  };

  const getRiskColor = (risk) => {
    switch (risk) {
      case 'safe': return 'border-green-500/30 bg-green-500/10';
      case 'moderate': return 'border-yellow-500/30 bg-yellow-500/10';
      case 'risky': return 'border-red-500/30 bg-red-500/10';
      default: return 'border-slate-500/30 bg-slate-500/10';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <Calculator className="w-6 h-6 text-green-400" />
        <h2 className="text-2xl font-bold text-white">Payout Calculations & Odds Analysis</h2>
      </div>

      {sampleParlays.map((parlay) => (
        <Card key={parlay.id} className="bg-slate-900/50 backdrop-blur-sm border-slate-700/50 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold text-white">{parlay.title}</h3>
            <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
              Success Rate: {parlay.winRate}%
            </Badge>
          </div>

          {/* Parlay Legs */}
          <div className="space-y-3 mb-6">
            {parlay.legs.map((leg, index) => (
              <div key={index} className={`p-4 rounded-lg border ${getRiskColor(leg.risk)}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    {getRiskIcon(leg.risk)}
                    <div>
                      <p className="text-white font-medium">{leg.team} {leg.betType}</p>
                      <p className="text-slate-400 text-sm">Odds: {leg.odds}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="w-24 bg-slate-700 rounded-full h-2 mb-1">
                      <div
                        className="bg-gradient-to-r from-green-500 to-blue-500 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${leg.confidence}%` }}
                      />
                    </div>
                    <p className="text-xs text-slate-400">{leg.confidence}% confidence</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Payout Calculation */}
          <div className="bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-lg p-4 mb-4">
            <div className="flex items-center justify-between mb-3">
              <div>
                <p className="text-slate-400 text-sm">Combined Odds</p>
                <p className="text-2xl font-bold text-white">{parlay.combinedOdds}</p>
              </div>
              <div className="text-right">
                <p className="text-slate-400 text-sm">Potential Payout</p>
                <p className="text-2xl font-bold text-green-400">${parlay.payout}</p>
              </div>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-400">Your ${stake} would return:</span>
              <span className="text-green-400 font-medium">+${(Number(parlay.payout) - stake).toFixed(2)} profit</span>
            </div>
          </div>

          {/* Best Platforms */}
          <div className="bg-slate-800/30 rounded-lg p-4 mb-4">
            <p className="text-slate-400 text-sm mb-2">Best platforms for these odds:</p>
            <div className="flex flex-wrap gap-2">
              {parlay.bestPlatforms.map((platform, index) => (
                <Badge key={index} variant="outline" className="border-blue-500/30 text-blue-400">
                  {platform}
                </Badge>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-3">
            <Button className="flex-1 bg-blue-500 hover:bg-blue-600 text-white">
              <ExternalLink className="w-4 h-4 mr-2" />
              Compare Across Platforms
            </Button>
            <Button variant="outline" className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-800">
              <TrendingUp className="w-4 h-4 mr-2" />
              Analyze Different Combo
            </Button>
          </div>
        </Card>
      ))}
    </div>
  );
};
