
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calculator, DollarSign, Target } from 'lucide-react';

export const ParlayBuilder = ({ onBuildParlay }) => {
  const [sport, setSport] = useState('');
  const [stake, setStake] = useState('');
  const [selectedGames, setSelectedGames] = useState([]);
  const [highConfidenceOnly, setHighConfidenceOnly] = useState(true);
  const [limitLegs, setLimitLegs] = useState(false);

  // Define sports by season - showing what's currently active
  const sportsData = {
    'in-season': {
      label: 'In Season Now',
      sports: [
        { value: 'nfl', label: 'NFL' },
        { value: 'nba', label: 'NBA' },
        { value: 'nhl', label: 'NHL' },
        { value: 'college-football', label: 'College Football' },
        { value: 'college-basketball', label: 'College Basketball' }
      ]
    },
    'baseball': {
      label: 'Baseball',
      sports: [
        { value: 'mlb', label: 'MLB' },
        { value: 'college-baseball', label: 'College Baseball' }
      ]
    },
    'soccer': {
      label: 'Soccer',
      sports: [
        { value: 'mls', label: 'MLS' },
        { value: 'premier-league', label: 'Premier League' },
        { value: 'champions-league', label: 'Champions League' },
        { value: 'la-liga', label: 'La Liga' },
        { value: 'bundesliga', label: 'Bundesliga' }
      ]
    },
    'other': {
      label: 'Other Sports',
      sports: [
        { value: 'tennis', label: 'Tennis' },
        { value: 'golf', label: 'Golf' },
        { value: 'ufc', label: 'UFC/MMA' },
        { value: 'boxing', label: 'Boxing' },
        { value: 'nascar', label: 'NASCAR' },
        { value: 'f1', label: 'Formula 1' },
        { value: 'esports', label: 'eSports' }
      ]
    }
  };

  // Sample games data based on sport category
  const getGamesForSport = (sportValue) => {
    const gameData = {
      'nfl': [
        { id: 1, matchup: 'Chiefs vs Bills', league: 'NFL' },
        { id: 2, matchup: 'Cowboys vs Eagles', league: 'NFL' },
        { id: 3, matchup: 'Packers vs Vikings', league: 'NFL' },
        { id: 4, matchup: '49ers vs Seahawks', league: 'NFL' }
      ],
      'nba': [
        { id: 5, matchup: 'Lakers vs Warriors', league: 'NBA' },
        { id: 6, matchup: 'Celtics vs Heat', league: 'NBA' },
        { id: 7, matchup: 'Nuggets vs Suns', league: 'NBA' },
        { id: 8, matchup: 'Bucks vs 76ers', league: 'NBA' }
      ],
      'mlb': [
        { id: 9, matchup: 'Yankees vs Red Sox', league: 'MLB' },
        { id: 10, matchup: 'Dodgers vs Giants', league: 'MLB' },
        { id: 11, matchup: 'Astros vs Rangers', league: 'MLB' }
      ],
      'college-football': [
        { id: 12, matchup: 'Alabama vs Georgia', league: 'College Football' },
        { id: 13, matchup: 'Ohio State vs Michigan', league: 'College Football' },
        { id: 14, matchup: 'Texas vs Oklahoma', league: 'College Football' }
      ],
      'premier-league': [
        { id: 15, matchup: 'Man City vs Arsenal', league: 'Premier League' },
        { id: 16, matchup: 'Liverpool vs Chelsea', league: 'Premier League' }
      ],
      'tennis': [
        { id: 17, matchup: 'Djokovic vs Nadal', league: 'ATP Tour' },
        { id: 18, matchup: 'Swiatek vs Gauff', league: 'WTA Tour' }
      ]
    };
    
    return gameData[sportValue] || [];
  };

  const handleCalculateParlay = () => {
    if (sport && stake && selectedGames.length > 0) {
      const parlayData = {
        sport,
        stake: parseFloat(stake),
        games: selectedGames,
        settings: { highConfidenceOnly, limitLegs }
      };
      onBuildParlay(parlayData);
    }
  };

  const selectedSportGames = sport ? getGamesForSport(sport) : [];

  return (
    <Card className="bg-slate-900/50 backdrop-blur-sm border-slate-700/50 p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="bg-gradient-to-r from-green-500 to-blue-500 p-2 rounded-lg">
          <Calculator className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-white">Parlay Calculator & Odds Analyzer</h2>
          <p className="text-slate-400 text-sm">Calculate payouts & compare odds across sportsbooks</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Sport Selection with Tabs */}
        <div className="md:col-span-2 space-y-2">
          <Label className="text-slate-300">Select Sport & League</Label>
          <Tabs defaultValue="in-season" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-slate-800/50 border-slate-600">
              {Object.entries(sportsData).map(([key, category]) => (
                <TabsTrigger 
                  key={key} 
                  value={key}
                  className="text-slate-300 data-[state=active]:bg-slate-700 data-[state=active]:text-white"
                >
                  {category.label}
                </TabsTrigger>
              ))}
            </TabsList>
            
            {Object.entries(sportsData).map(([key, category]) => (
              <TabsContent key={key} value={key} className="mt-4">
                <Select value={sport} onValueChange={setSport}>
                  <SelectTrigger className="bg-slate-800/50 border-slate-600 text-white">
                    <SelectValue placeholder={`Choose from ${category.label.toLowerCase()}...`} />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-600">
                    {category.sports.map((sportOption) => (
                      <SelectItem key={sportOption.value} value={sportOption.value}>
                        {sportOption.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </TabsContent>
            ))}
          </Tabs>
        </div>

        {/* Hypothetical Bet Amount */}
        <div className="space-y-2">
          <Label htmlFor="stake" className="text-slate-300">Hypothetical Bet Amount</Label>
          <div className="relative">
            <DollarSign className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <Input
              id="stake"
              type="number"
              placeholder="0.00"
              value={stake}
              onChange={(e) => setStake(e.target.value)}
              className="bg-slate-800/50 border-slate-600 text-white pl-10"
            />
          </div>
        </div>
      </div>

      {/* Game Selection */}
      {selectedSportGames.length > 0 && (
        <div className="mt-6 space-y-2">
          <Label className="text-slate-300">Select Games for Analysis (up to 6)</Label>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {selectedSportGames.map((game) => (
              <div
                key={game.id}
                className={`p-3 rounded-lg border cursor-pointer transition-all duration-200 ${
                  selectedGames.includes(game.id)
                    ? 'bg-green-500/20 border-green-500 ring-1 ring-green-500'
                    : 'bg-slate-800/30 border-slate-600 hover:border-slate-500'
                }`}
                onClick={() => {
                  if (selectedGames.includes(game.id)) {
                    setSelectedGames(selectedGames.filter(id => id !== game.id));
                  } else if (selectedGames.length < 6) {
                    setSelectedGames([...selectedGames, game.id]);
                  }
                }}
              >
                <p className="text-white font-medium">{game.matchup}</p>
                <p className="text-slate-400 text-sm">{game.league}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Analysis Settings */}
      <div className="mt-6 space-y-4">
        <div className="flex items-center justify-between">
          <Label htmlFor="confidence" className="text-slate-300">Only analyze picks with 85%+ confidence</Label>
          <Switch
            id="confidence"
            checked={highConfidenceOnly}
            onCheckedChange={setHighConfidenceOnly}
          />
        </div>
        <div className="flex items-center justify-between">
          <Label htmlFor="limit" className="text-slate-300">Limit analysis to 4 legs max (safer parlays)</Label>
          <Switch
            id="limit"
            checked={limitLegs}
            onCheckedChange={setLimitLegs}
          />
        </div>
      </div>

      {/* Calculate Button */}
      <Button
        onClick={handleCalculateParlay}
        disabled={!sport || !stake || selectedGames.length === 0}
        className="w-full mt-6 bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white font-semibold py-3"
      >
        <Calculator className="w-5 h-5 mr-2" />
        Calculate Payout & Find Best Odds
      </Button>
    </Card>
  );
};
