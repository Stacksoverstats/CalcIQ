
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Plus, TrendingUp, Target, Calculator, ExternalLink } from 'lucide-react';

export const SmartSuggestions = () => {
  const suggestions = [
    {
      id: 1,
      matchup: "Dodgers vs Giants",
      betType: "Over 8.5 Runs",
      odds: "-115",
      confidence: 94,
      reason: "Both teams average 5.2 runs/game",
      bestOdds: "DraftKings: -110"
    },
    {
      id: 2,
      matchup: "Yankees vs Red Sox",
      betType: "Yankees ML",
      odds: "-140",
      confidence: 89,
      reason: "Yankees 8-2 in last 10 vs Boston",
      bestOdds: "FanDuel: -135"
    },
    {
      id: 3,
      matchup: "LSU vs Florida",
      betType: "LSU -1.5",
      odds: "+105",
      confidence: 87,
      reason: "LSU's ace pitcher vs weak Florida lineup",
      bestOdds: "BetMGM: +110"
    },
    {
      id: 4,
      matchup: "Astros vs Rangers",
      betType: "Under 9.5 Runs",
      odds: "-105",
      confidence: 91,
      reason: "Strong pitching matchup, windy conditions",
      bestOdds: "Caesars: -102"
    },
    {
      id: 5,
      matchup: "Alabama vs Auburn",
      betType: "Alabama ML",
      odds: "-120",
      confidence: 85,
      reason: "Alabama undefeated at home this season",
      bestOdds: "PointsBet: -115"
    }
  ];

  return (
    <Card className="bg-slate-900/50 backdrop-blur-sm border-slate-700/50 p-6 sticky top-24">
      <div className="flex items-center space-x-3 mb-6">
        <div className="bg-gradient-to-r from-green-500 to-blue-500 p-2 rounded-lg">
          <Calculator className="w-5 h-5 text-white" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-white">Value Picks</h3>
          <p className="text-xs text-slate-400">Best odds analysis</p>
        </div>
      </div>

      <div className="space-y-4">
        {suggestions.map((suggestion) => (
          <div key={suggestion.id} className="bg-slate-800/30 rounded-lg p-4 border border-slate-700/50">
            <div className="flex items-start justify-between mb-3">
              <div className="flex-1">
                <p className="text-white font-medium text-sm">{suggestion.matchup}</p>
                <p className="text-blue-400 font-semibold">{suggestion.betType}</p>
                <p className="text-slate-400 text-xs">Standard: {suggestion.odds}</p>
                <p className="text-green-400 text-xs font-medium">{suggestion.bestOdds}</p>
              </div>
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-xs">
                {suggestion.confidence}%
              </Badge>
            </div>

            {/* Confidence Bar */}
            <div className="w-full bg-slate-700 rounded-full h-1.5 mb-3">
              <div
                className="bg-gradient-to-r from-green-500 to-blue-500 h-1.5 rounded-full transition-all duration-300"
                style={{ width: `${suggestion.confidence}%` }}
              />
            </div>

            <p className="text-slate-400 text-xs mb-3">{suggestion.reason}</p>

            <div className="flex space-x-2">
              <Button size="sm" className="flex-1 bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 border border-blue-500/30">
                <Plus className="w-3 h-3 mr-1" />
                Add to Calculator
              </Button>
              <Button size="sm" variant="outline" className="border-slate-600 text-slate-400 hover:bg-slate-700">
                <ExternalLink className="w-3 h-3" />
              </Button>
            </div>
          </div>
        ))}
      </div>

      {/* Today's Best Value */}
      <div className="mt-6 p-4 bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-lg border border-green-500/30">
        <div className="flex items-center space-x-2 mb-2">
          <Target className="w-4 h-4 text-green-400" />
          <p className="text-green-400 font-semibold text-sm">Best Value Today</p>
        </div>
        <p className="text-white font-medium">Dodgers Over 8.5 Runs</p>
        <p className="text-slate-400 text-xs">94% confidence • DraftKings has best odds at -110</p>
      </div>
    </Card>
  );
};
