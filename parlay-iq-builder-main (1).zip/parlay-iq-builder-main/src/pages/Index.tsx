
import { useState } from 'react';
import { ParlayBuilder } from '@/components/ParlayBuilder';
import { ParlayResults } from '@/components/ParlayResults';
import { SmartSuggestions } from '@/components/SmartSuggestions';
import { LiveTracker } from '@/components/LiveTracker';
import { Navigation } from '@/components/Navigation';
import { Calculator, Target, BarChart3, TrendingUp } from 'lucide-react';

const Index = () => {
  const [activeScreen, setActiveScreen] = useState('home');
  const [parlayData, setParlayData] = useState(null);

  const renderScreen = () => {
    switch (activeScreen) {
      case 'home':
        return (
          <div className="space-y-6">
            <ParlayBuilder onBuildParlay={setParlayData} />
            {parlayData && <ParlayResults parlayData={parlayData} />}
          </div>
        );
      case 'live':
        return <LiveTracker />;
      case 'history':
        return (
          <div className="bg-slate-900/50 rounded-2xl p-8 text-center">
            <BarChart3 className="w-16 h-16 text-green-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">Calculation History</h2>
            <p className="text-slate-400">Your past parlay calculations and odds analysis will appear here</p>
          </div>
        );
      case 'settings':
        return (
          <div className="bg-slate-900/50 rounded-2xl p-8 text-center">
            <Target className="w-16 h-16 text-green-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">Settings</h2>
            <p className="text-slate-400">Configure your preferred sportsbooks and odds comparison settings</p>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800">
      {/* Header */}
      <header className="bg-slate-900/80 backdrop-blur-sm border-b border-slate-700/50 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-green-500 to-blue-500 p-2 rounded-xl">
                <Calculator className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">ParlayIQ</h1>
                <p className="text-sm text-slate-400">Smart Parlay Calculator & Odds Analyzer</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-slate-400">Analysis Tool</p>
              <p className="text-xl font-bold text-green-400">Calculate · Compare · Win</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Content Area */}
          <div className="lg:col-span-3">
            {renderScreen()}
          </div>
          
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <SmartSuggestions />
          </div>
        </div>
      </main>

      {/* Navigation */}
      <Navigation activeScreen={activeScreen} onScreenChange={setActiveScreen} />
    </div>
  );
};

export default Index;
